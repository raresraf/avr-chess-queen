#ifndef BK_H
#define BK_H

void bk_tests();
void test_position(int index);

#endif
