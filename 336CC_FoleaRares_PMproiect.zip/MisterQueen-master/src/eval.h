#ifndef EVAL_H
#define EVAL_H

#include "board.h"

int evaluate(Board *board);
int evaluate_pawns(Board *board);

#endif
