#ifndef UCI_H
#define UCI_H

void uci_main();

#endif
